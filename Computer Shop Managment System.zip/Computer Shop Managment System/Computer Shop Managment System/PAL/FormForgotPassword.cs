﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Computer_Shop_Managment_System.PAL
{
    public partial class FormForgotPassword : Form
    {
        public FormForgotPassword()
        {
            InitializeComponent();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnResetPassword_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please Enter Username.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // end if

            if (txtEmail.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please Enter Your Email.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // end if

            else
            {
                string pass = Computer.Computer.ForgotPassword(txtUsername.Text.Trim(), txtEmail.Text.Trim());
                if (pass != string.Empty)
                {
                   
                   
                   MessageBox.Show("Your password is: " + pass, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   Close();
                }
                else{
                    MessageBox.Show("Username or Email Is Incorrect.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            
                
            
            }
            //end else
        }

        private void FormForgotPassword_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

      
    }
}
