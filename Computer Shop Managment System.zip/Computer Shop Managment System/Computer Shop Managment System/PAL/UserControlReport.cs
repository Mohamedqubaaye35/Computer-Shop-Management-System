﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Computer_Shop_Managment_System.PAL
{
    public partial class UserControlReport : UserControl
    {
        public UserControlReport()
        {
            InitializeComponent();
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            FormReport formReport = new FormReport();
            formReport.startDate = dtpStartDate.Value.Date;
            formReport.endDate = dtpEndDate.Value.Date;
            formReport.ShowDialog();

        }
    }
}
