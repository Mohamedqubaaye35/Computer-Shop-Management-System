﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Computer_Shop_Managment_System.PAL
{
    public partial class FormLogIn : Form
    {
        public FormLogIn()
        {
            InitializeComponent();
        }

        private void EmptyBox()
        {
            txtUsername.Clear();
            txtPassword.Clear();
        }

        private void FormLogIn_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void picShow_Click(object sender, EventArgs e)
        {
            if (picShow.Visible == true)
            {
                txtPassword.UseSystemPasswordChar = false;
                picShow.Visible = false;
                picHide.Visible = true;

            }

            // end method
        }

        private void FormLogIn_Click(object sender, EventArgs e)
        {

        }

        private void picHide_Click(object sender, EventArgs e)
        {
            if (picHide.Visible == true)
            {
                txtPassword.UseSystemPasswordChar = true;
                picShow.Visible = true;
                picHide.Visible = false;

            }

            // end if

        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnLogIn_Click_1(object sender, EventArgs e)
        {
              if (txtUsername.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please Enter Username.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // end if

            if (txtPassword.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please Enter Password.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // end if

            else
            {
                bool check = Computer.Computer.IsValidNamePass(txtUsername.Text.Trim(), txtPassword.Text.Trim());
                if (check)
                { 
                   FormMain formMain = new FormMain();
                    formMain.name = txtUsername.Text;
                    formMain.ShowDialog();
                   EmptyBox();
                }
                else{
                    MessageBox.Show("Username or Password Is Incorrect.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            
                
            
            }
            //end else
        }

        private void lblForgotPassword_Click(object sender, EventArgs e)
        {
            FormForgotPassword formForgotPassword = new FormForgotPassword();
            formForgotPassword.ShowDialog();
        }
        }
    
}
