﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Computer_Shop_Managment_System.PAL
{
    public partial class UserControlDashboard : UserControl
    {
        public UserControlDashboard()
        {
            InitializeComponent();
        }
        public void Count()
        {
            lblTotalProduct.Text = Computer.Computer.Count("SELECT COUNT(*) FROM Product;").ToString();
            lblTotalOders.Text = Computer.Computer.Count("SELECT COUNT(*) FROM Orders WHERE Payment_Status = 'Paid';").ToString();
            lblLowStock.Text = Computer.Computer.Count("SELECT COUNT(*) FROM Product WHERE Product_Status = 'Available';").ToString();
            lblTotalRevenue.Text = Computer.Computer.Count("SELECT SUM(Grand_Total) FROM Orders;").ToString();
        
        }

        private void UserControlDashboard_Load(object sender, EventArgs e)
        {
            Count();
        }

       

       


       

        

       
    }
}
